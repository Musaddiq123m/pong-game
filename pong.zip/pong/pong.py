import pygame
import sys

pygame.init()
pygame.mixer.init()

# Constants
GOLD = '#E88817'
GREEN = '#008264'
right = 'right'
left = 'left'
one = 'one'
two = 'two'
# Screen setup
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Pong")

# Font setup
test_font = pygame.font.Font('pong/font/font.otf', 50)

clock = pygame.time.Clock()
class MiddleLine(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((2.5, screen_height))
        self.image.fill('White')
        self.rect = self.image.get_rect(midtop=(screen_width / 2, 0))
    
    def update(self):
        pass

class Paddle(pygame.sprite.Sprite):
    def __init__(self, side, mode):
        super().__init__()
        self.side = side
        self.mode = mode
        self.image = pygame.image.load('pong/paddle.png')
        if side == right:
            self.rect = self.image.get_rect(midright=(screen_width, screen_height / 2))
        elif side == left:
            self.rect = self.image.get_rect(midleft=(0, screen_height / 2))

    def makeAi(self):
        if self.side == left and self.mode == two:
            self.mode = one
    
    def makeTwo(self):
        if self.side == left and self.mode == one:
            self.mode = two
    
    def Up(self):
        self.rect.y -= 5
        if self.rect.top <= 0:
            self.rect.top = 0    
    
    def Down(self):
        self.rect.y += 5
        if self.rect.bottom >= screen_height:
            self.rect.bottom = screen_height
            
    def movePad(self, y):
        if self.rect.centery < y:
            self.Down()
        elif self.rect.centery > y:
            self.Up()

    def calculatePosition(self, ball):
        if ball.x_change < 0:
            self.movePad(ball.rect.centery)
                 
    def update(self, ball=None):
        keys = pygame.key.get_pressed()
        if self.side == right:
            if keys[pygame.K_UP]:
                self.Up()
            elif keys[pygame.K_DOWN]:
                self.Down()
        elif self.side == left:
            if self.mode == two:
                if keys[pygame.K_w]:
                    self.Up()
                elif keys[pygame.K_s]:
                    self.Down()
            elif self.mode == one and ball:
                self.calculatePosition(ball)

class Ball(pygame.sprite.Sprite):
    def __init__(self, speed):
        super().__init__()
        self.hit = pygame.mixer.Sound('pong/pop.ogg')
        self.radius = 25
        self.image = pygame.Surface((self.radius * 2, self.radius * 2), pygame.SRCALPHA)
        self.rect = self.image.get_rect(center=(screen_width / 2, screen_height / 2))
        self.x_change = speed
        self.y_change = speed
        self.draw_circle()

    def draw_circle(self):
        pygame.draw.circle(self.image, 'Red', (self.radius, self.radius), self.radius)

    def collidePaddle(self, right_paddle, left_paddle):
        if self.rect.colliderect(left_paddle):
            self.hit.play()
            if abs(left_paddle.top - self.rect.bottom) < 10 and self.y_change > 0:
                self.y_change *= -1
            if abs(left_paddle.bottom - self.rect.top) < 10 and self.y_change < 0:
                self.y_change *= -1
            if abs(left_paddle.right - self.rect.left) < 10 and self.x_change < 0:
                self.x_change *= -1
            if abs(left_paddle.left - self.rect.right) < 10 and self.x_change > 0:
                self.x_change *= -1

        elif self.rect.colliderect(right_paddle):
            self.hit.play()
            if abs(right_paddle.top - self.rect.bottom) < 10 and self.y_change > 0:
                self.y_change *= -1
            if abs(right_paddle.bottom - self.rect.top) < 10 and self.y_change < 0:
                self.y_change *= -1
            if abs(right_paddle.right - self.rect.left) < 10 and self.x_change < 0:
                self.x_change *= -1
            if abs(right_paddle.left - self.rect.right) < 10 and self.x_change > 0:
                self.x_change *= -1

    def update(self):
        self.rect.x += self.x_change
        self.rect.y += self.y_change
        if self.rect.bottom >= screen_height or self.rect.top <= 0:
            self.y_change *= -1

    def Rightlose(self):
        return self.rect.right >= screen_width

    def LeftLose(self):
        return self.rect.left <= 0

    def change_speed(self, new_speed):
        if self.x_change > 0:
            self.x_change = new_speed
        else:
            self.x_change = -new_speed

        if self.y_change > 0:
            self.y_change = new_speed
        else:
            self.y_change = -new_speed

class Game:
    def __init__(self):
        self.game_state = -1
        self.mode = two
        
        self.middleLine = MiddleLine()
        self.right_paddle = Paddle(right, two)
        self.left_paddle = Paddle(left, two)
        self.ball = Ball(5)

        self.group = pygame.sprite.Group()
        self.group.add(self.middleLine)
        self.group.add(self.right_paddle)
        self.group.add(self.left_paddle)
        self.group.add(self.ball)
        
        self.starting_speed = 3
        self.speed = self.starting_speed
        self.start_time = 0
        self.two_player_rect = None
        self.one_player_rect = None
        self.restart_rect = None
        self.start_state_rect = None

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if self.game_state == -1:
                    if self.two_player_rect and self.two_player_rect.collidepoint(event.pos):
                        self.game_state = 1
                    elif self.one_player_rect and self.one_player_rect.collidepoint(event.pos):
                        self.game_state = 4
                elif self.game_state in [2, 3]:
                    if self.restart_rect and self.restart_rect.collidepoint(event.pos):
                        if self.mode == two:
                            self.game_state = 1
                        else:
                            self.game_state = 4 
                        self.starting_values()
                    elif self.start_state_rect and self.start_state_rect.collidepoint(event.pos):
                        self.game_state = -1
                        self.starting_values()               

    def Start_state(self):
        self.handle_events()
        screen.fill('Black')
        
        two_player_surface = pygame.Surface((300, 150))
        two_player_surface.fill(GREEN)
        self.two_player_rect = two_player_surface.get_rect(center=(screen_width / 2 - 200, screen_height / 2))
        screen.blit(two_player_surface, self.two_player_rect)
        two_player_text = test_font.render("Two Player", True, (255, 255, 255))
        two_player_text_rect = two_player_text.get_rect(center=self.two_player_rect.center)
        screen.blit(two_player_text, two_player_text_rect)

        one_player_surface = pygame.Surface((300, 150))
        one_player_surface.fill(GOLD)
        self.one_player_rect = one_player_surface.get_rect(center=(screen_width / 2 + 200, screen_height / 2))
        screen.blit(one_player_surface, self.one_player_rect)
        one_player_text = test_font.render("One Player", True, (255, 255, 255))
        one_player_text_rect = one_player_text.get_rect(center=self.one_player_rect.center)
        screen.blit(one_player_text, one_player_text_rect)

        pygame.display.flip()

    def Playstate(self, mode):
        self.handle_events()
        if mode == one:
            self.left_paddle.makeAi()  # Set left paddle to AI mode
        else:
            self.left_paddle.makeTwo()  # Set left paddle to player mode
        screen.fill('Black') 
        
        self.group.draw(screen)
        self.right_paddle.update()
        if mode == one:
            self.left_paddle.update(self.ball)
        else:
            self.left_paddle.update()
        self.ball.update()
        self.ball.collidePaddle(self.right_paddle.rect, self.left_paddle.rect)
        self.middleLine.update()
        
        if self.ball.Rightlose():
            self.game_state = 2
        elif self.ball.LeftLose():
            self.game_state = 3
        
        current_time = pygame.time.get_ticks()
        if current_time - self.start_time >= 1000:
            self.speed += 0.1
            self.ball.change_speed(int(self.speed))
            self.start_time = current_time
         
        pygame.display.flip()

    def SinglePlayerState(self):
        self.mode = one  # Set game mode to single player
        self.Playstate(one)

    def TwoPlayerState(self):
        self.mode = two  # Set game mode to two player
        self.Playstate(two)

    def starting_values(self):
        self.ball.rect.center = (screen_width / 2, screen_height / 2) 
        self.ball.change_speed(self.starting_speed)
        self.speed = self.starting_speed
        self.left_paddle.rect.center = (0, screen_height / 2)
        self.right_paddle.rect.center = (screen_width, screen_height / 2)
        self.left_paddle.mode = self.mode  # Set left paddle mode based on game mode
        
        if self.mode == one:
            self.left_paddle.makeAi()
        else:
            self.left_paddle.makeTwo()

    def show_endgame_options(self):
        restart_surface = pygame.Surface((300, 150))
        restart_surface.fill(GREEN)
        self.restart_rect = restart_surface.get_rect(center=(screen_width / 2 - 200, screen_height / 2 + 50))
        screen.blit(restart_surface, self.restart_rect)
        restart_text = test_font.render("Restart", True, (255, 255, 255))
        restart_text_rect = restart_text.get_rect(center=self.restart_rect.center)
        screen.blit(restart_text, restart_text_rect)

        start_state_surface = pygame.Surface((300, 150))
        start_state_surface.fill(GOLD)
        self.start_state_rect = start_state_surface.get_rect(center=(screen_width / 2 + 200, screen_height / 2 + 50))
        screen.blit(start_state_surface, self.start_state_rect)
        start_state_text = test_font.render("Main Menu", True, (255, 255, 255))
        start_state_text_rect = start_state_text.get_rect(center=self.start_state_rect.center)
        screen.blit(start_state_text, start_state_text_rect)

    def RightLostState(self):
        self.handle_events()
        screen.fill('Black')
        gameover_surface = test_font.render("Game Over, Left Won!", True, (211, 33, 45))
        gameover_rect = gameover_surface.get_rect(center=(screen_width / 2, screen_height / 2 - 50))
        screen.blit(gameover_surface, gameover_rect)
        
        self.show_endgame_options()
        
        pygame.display.flip()  

    def LeftLostState(self):
        self.handle_events()
        screen.fill('Black')
        gameover_surface = test_font.render("Game Over, Right Won!", True, (211, 33, 45))
        gameover_rect = gameover_surface.get_rect(center=(screen_width / 2, screen_height / 2 - 50))
        screen.blit(gameover_surface, gameover_rect)
        
        self.show_endgame_options()
        
        pygame.display.flip()  
 
    def state_manager(self):
        if self.game_state == -1:
            self.Start_state()
        elif self.game_state == 1:
            self.TwoPlayerState()
        elif self.game_state == 2:
            self.RightLostState()
        elif self.game_state == 3:
            self.LeftLostState()
        elif self.game_state == 4:
            self.SinglePlayerState()

game = Game()

while True:
    game.state_manager()    
    clock.tick(60)
